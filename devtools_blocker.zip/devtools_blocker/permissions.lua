checkmethod = 'steam' ---- replace with 'steam' or 'SQL'
extendedVersionV1Final = false
--if checkmethod is steam 
--will allow players in allowlist to open nui_devtool

-- if use es extended in version v1 final (in db save license, not steam) and checkmetode = SQL then type true in es_extendedV1Final

--if checkmethod is SQL 
--will check user.group in SQL 
--allow admin and superadmin to open nui_devtool 

allowlist = {
'steam:110000135910727',
'steam:11000011C0FDDBE'
}
