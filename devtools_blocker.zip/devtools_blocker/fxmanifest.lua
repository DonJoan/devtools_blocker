fx_version 'bodacious'
game 'gta5'


client_script "client.lua"
server_script {
	"server.lua",
	"permissions.lua"
}

ui_page 'html/index.html'

files {
	'client/index.html'
}

