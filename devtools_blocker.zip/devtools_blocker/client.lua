RegisterNUICallback('callback', function()
  TriggerServerEvent('cooltrigger')
end)
